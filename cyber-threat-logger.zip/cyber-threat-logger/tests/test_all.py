"""Run: python -m unittest discover -s tests -v   (also works with pytest)"""
import csv, json, os, sys, tempfile, threading, unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest import mock
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, core, mitre, detectors, notify, elk, app as appmod

class Base(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory(); core.DB = os.path.join(self.d.name, "t.db"); self.c = core.conn()
        for k in ("NOTIFY_SMTP_HOST", "NOTIFY_TO", "ELK_URL"): os.environ.pop(k, None)
    def tearDown(self): self.c.close(); self.d.cleanup()

def pkt(ts, ip="10.0.0.9", port=80, pay=None): return {"ts": ts, "src_ip": ip, "dst_ip": "10.0.0.1", "dport": port, "length": 100, "payload": pay}

class TestML(Base):
    def test_train_heldout_and_anomaly(self):
        m = core.train(n=2000); self.assertGreater(m["test_rows"], 0); self.assertIn("anomaly", m)
        self.assertLess(m["anomaly"]["flag_rate_on_benign_test"], .2)
    def test_predict_validation(self):
        f = core.sample("ddos", np.random.default_rng(1)); self.assertIn(core.predict(f)[0], core.CLASSES)
        with self.assertRaises(ValueError): core.predict({"dport": 80})
        with self.assertRaises(ValueError): core.predict({**f, "dport": float("nan")})
    def test_train_csv_real_path(self):
        p = os.path.join(self.d.name, "d.csv"); df = core.synth(600, 3).rename(columns={"label": "lbl"}); df.to_csv(p, index=False)
        m = core.train_csv(p, "lbl"); self.assertTrue(m["data"].startswith("REAL CSV"))
        with self.assertRaises(ValueError): core.train_csv(p, "nope")
        core.train()   # restore default artifacts

class TestRules(Base):
    def test_ddos_once_per_cooldown(self):
        a = detectors.process([pkt(i * .1) for i in range(120)], "simulated", self.c)
        self.assertEqual([x["predicted"] for x in a], ["ddos"]); self.assertEqual(a[0]["rule"] in ("rule-based", "RandomForest"), True)
    def test_sqli_bruteforce_portscan(self):
        self.assertTrue(any(x["predicted"] == "sqli" for x in detectors.process([pkt(1, pay="x' OR '1'='1")], "simulated", self.c)))
        self.assertTrue(any(x["predicted"] == "bruteforce" for x in detectors.process([pkt(i, "10.0.0.5", 22, "Failed login") for i in range(8)], "simulated", self.c)))
        self.assertTrue(any(x["predicted"] == "portscan" for x in detectors.process([pkt(i * .1, "10.0.0.6", 1000 + i) for i in range(30)], "simulated", self.c)))
    def test_payload_not_stored(self):
        detectors.process([pkt(1, pay="SECRETDATA ' OR '1'='1")], "simulated", self.c)
        self.assertNotIn("SECRETDATA", json.dumps([tuple(r) for r in self.c.execute("SELECT * FROM events")]))
    def test_benign_no_alert(self): self.assertEqual(detectors.process([pkt(i * 5) for i in range(5)], "simulated", self.c), [])

class TestLedger(Base):
    def test_persist_verify_tamper_delete(self):
        for k in ["benign", "ddos", "sqli", "portscan"]: core.simulate(k, self.c)
        self.assertTrue(core.verify(core.conn())["ok"])
        self.c.execute("UPDATE events SET severity='None' WHERE seq=2"); self.c.commit(); self.assertFalse(core.verify(self.c)["ok"])
        self.c.execute("DELETE FROM events WHERE seq=3"); self.c.commit(); self.assertTrue(any("link" in e["reason"] for e in core.verify(self.c)["errors"]))
    def test_status_and_metadata_dont_break_chain(self):
        e = core.simulate("ddos", self.c); self.c.execute("UPDATE events SET status='closed', notified=1 WHERE id=?", (e["id"],)); self.c.commit()
        self.assertTrue(core.verify(self.c)["ok"])
    def test_migration_old_schema(self):
        import sqlite3; p = os.path.join(self.d.name, "old.db"); o = sqlite3.connect(p)
        o.execute("CREATE TABLE events(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE,ts TEXT,source TEXT,src_ip TEXT,dst_ip TEXT,proto TEXT,dport INTEGER,features TEXT,predicted TEXT,severity TEXT,confidence REAL,rule TEXT,status TEXT,prev_hash TEXT,hash TEXT)"); o.commit(); o.close()
        c = core.conn(p); core.simulate("sqli", c); self.assertTrue(core.verify(c)["ok"]); c.close()
    def test_invalid_ingest(self):
        with self.assertRaises(ValueError): core.ingest({"src_ip": "bad", "dst_ip": "1.1.1.1", "features": {}}, "dataset", self.c)

class TestMitre(unittest.TestCase):
    def test_map(self):
        self.assertEqual(mitre.lookup("bruteforce")["id"], "T1110"); self.assertIsNone(mitre.lookup("benign"))

class TestCSV(Base):
    def _csv(self, rows):
        p = os.path.join(self.d.name, "i.csv")
        with open(p, "w", newline="") as f: w = csv.writer(f); w.writerow(core.FEATURES + ["src_ip"]); w.writerows(rows)
        return p
    def test_import_valid_and_invalid_rows(self):
        good = [list(core.sample("sqli", np.random.default_rng(2)).values()) + ["10.1.1.1"]]
        r = core.import_csv(self._csv(good + [["x"] * 6 + ["10.1.1.1"], good[0][:6] + ["not-ip"]]), c=self.c)
        self.assertEqual((r["imported"], r["invalid"]), (1, 2)); self.assertEqual(self.c.execute("SELECT source FROM events").fetchone()[0], "dataset")
    def test_missing_columns(self):
        p = os.path.join(self.d.name, "b.csv"); open(p, "w").write("a,b\n1,2\n")
        with self.assertRaises(ValueError): core.import_csv(p, c=self.c)

class TestNotify(Base):
    def test_email_threshold_dedupe_and_failure(self):
        os.environ.update(NOTIFY_SMTP_HOST="smtp.test", NOTIFY_TO="a@b.c")
        with mock.patch("smtplib.SMTP") as S:
            e = core.simulate("ddos", self.c)
            if e["severity"] in ("High", "Critical"): self.assertEqual(S.return_value.__enter__.return_value.send_message.call_count, 1)
            self.assertIsNone(notify.send_if_needed(e, self.c))   # deduped
            self.assertEqual(S.return_value.__enter__.return_value.send_message.call_count, 1)
        with mock.patch("smtplib.SMTP", side_effect=OSError):
            e2 = core.simulate("sqli", self.c); self.assertIn("email failed", self.c.execute("SELECT integration_note FROM events WHERE id=?", (e2["id"],)).fetchone()[0])
    def test_disabled_by_default(self): self.assertFalse(notify.enabled())

class TestELK(Base):
    def test_forward_to_local_stub_and_unreachable(self):
        got = []
        class H(BaseHTTPRequestHandler):
            def do_PUT(s): got.append(json.loads(s.rfile.read(int(s.headers["Content-Length"])))); s.send_response(201); s.end_headers(); s.wfile.write(b"{}")
            def do_GET(s): s.send_response(200); s.end_headers(); s.wfile.write(b"{}")
            def log_message(s, *a): pass
        srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
        os.environ["ELK_URL"] = f"http://127.0.0.1:{srv.server_port}"; core.simulate("ddos", self.c)
        self.assertEqual(got[0]["predicted"], "ddos"); self.assertTrue(elk.health()["reachable"]); srv.shutdown()
        os.environ["ELK_URL"] = "http://127.0.0.1:1"; e = core.simulate("sqli", self.c); self.assertIsNotNone(e)   # unreachable -> no crash

class TestAPI(Base):
    def test_end_to_end(self):
        c = appmod.app.test_client()
        self.assertEqual(c.post("/api/simulate", json={"kind": "x"}).status_code, 400)
        e = c.post("/api/simulate", json={"kind": "sqli"}).get_json()
        self.assertEqual(c.get("/api/events?source=simulated").get_json()[0]["id"], e["id"])
        self.assertEqual(json.loads(c.get(f"/api/events/{e['id']}").get_json()["mitre"])["id"], "T1190")
        self.assertEqual(c.patch(f"/api/events/{e['id']}", json={"status": "investigating"}).status_code, 200)
        self.assertTrue(c.get("/api/verify").get_json()["ok"]); self.assertEqual(c.get("/").status_code, 200)
        self.assertFalse(c.get("/api/tamper-demo").get_json()["after_tamper"]["ok"])
        self.assertIn("elk", c.get("/api/integrations").get_json())
    def test_csv_upload_validation(self):
        c = appmod.app.test_client()
        import io
        self.assertEqual(c.post("/api/import/csv", data={"file": (io.BytesIO(b"x"), "a.exe")}, content_type="multipart/form-data").status_code, 400)
        ok = ",".join(core.FEATURES) + "\n" + ",".join(map(str, core.sample("portscan", np.random.default_rng(5)).values())) + "\n"
        r = c.post("/api/import/csv", data={"file": (io.BytesIO(ok.encode()), "a.csv")}, content_type="multipart/form-data"); self.assertEqual(r.get_json()["imported"], 1)
    def test_live_unavailable_is_graceful(self):
        r = appmod.app.test_client().post("/api/live/start"); self.assertIn(r.status_code, (200, 503))

if __name__ == "__main__": unittest.main()

import struct, io, live
def make_pcap(path, pkts):
    with open(path, "wb") as f:
        f.write(struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))
        for ts, src, dport, pay in pkts:
            tcp = struct.pack(">HHIIBBHHH", 40000, dport, 0, 0, 5 << 4, 0x18, 8192, 0, 0) + pay
            ip = struct.pack(">BBHHHBBH4s4s", 0x45, 0, 20 + len(tcp), 0, 0, 64, 6, 0, bytes(map(int, src.split("."))), bytes([10, 0, 0, 1])) + tcp
            fr = b"\0" * 12 + b"\x08\x00" + ip
            f.write(struct.pack("<IIII", int(ts), int((ts % 1) * 1e6), len(fr), len(fr)) + fr)

class TestPCAP(Base):
    def test_pcap_flood_and_sqli_detected(self):
        p = os.path.join(self.d.name, "t.pcap")
        make_pcap(p, [(100 + i * .2, "10.9.9.9", 80, b"GET /") for i in range(80)] + [(200, "10.8.8.8", 80, b"id=1' OR '1'='1")])
        got = [x["predicted"] for x in live.import_pcap(p, self.c)]
        self.assertIn("ddos", got); self.assertIn("sqli", got)
        self.assertEqual(self.c.execute("SELECT DISTINCT source FROM events").fetchone()[0], "dataset")
        self.assertTrue(core.verify(self.c)["ok"])
    def test_bad_files(self):
        p = os.path.join(self.d.name, "bad.pcap"); open(p, "wb").write(b"not a pcap at all, just text....")
        with self.assertRaises(ValueError): live.import_pcap(p, self.c)
        with self.assertRaises(ValueError): live.import_pcap(os.path.join(self.d.name, "x.txt"), self.c)
    def test_pcap_upload_and_train_endpoints(self):
        c = appmod.app.test_client(); p = os.path.join(self.d.name, "u.pcap")
        make_pcap(p, [(50 + i * .1, "10.7.7.7", 22, b"Failed login") for i in range(10)])
        r = c.post("/api/import/pcap", data={"file": (open(p, "rb"), "u.pcap")}, content_type="multipart/form-data"); self.assertIn("bruteforce", r.get_json()["predicted"])
        self.assertEqual(c.post("/api/import/pcap", data={"file": (io.BytesIO(b"x"), "u.exe")}, content_type="multipart/form-data").status_code, 400)
        t = c.post("/api/train", data={}, content_type="multipart/form-data"); self.assertIn("SYNTHETIC", t.get_json()["data"])
        bad = c.post("/api/train", data={"file": (io.BytesIO(b"a,b\n1,2\n"), "t.csv"), "label_col": "z"}, content_type="multipart/form-data"); self.assertEqual(bad.status_code, 400)
