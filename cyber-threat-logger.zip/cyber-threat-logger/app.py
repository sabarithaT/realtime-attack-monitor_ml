"""Flask app: REST API + dashboard.  Run: python app.py  ->  http://127.0.0.1:5000"""
import json, os, tempfile
from flask import Flask, jsonify, request
import core, elk, notify, detectors
try:
    import live; LIVE = live.Live()
except Exception: LIVE = None

app = Flask(__name__)

def rows(q, args=()):
    c = core.conn()
    try: return [dict(r) for r in c.execute(q, args)]
    finally: c.close()

@app.get("/api/summary")
def summary():
    t = rows("SELECT COUNT(*) n, SUM(predicted!='benign') s FROM events")[0]
    return jsonify(total=t["n"], suspicious=t["s"] or 0,
        by_severity={r["severity"]: r["n"] for r in rows("SELECT severity, COUNT(*) n FROM events GROUP BY severity")},
        by_class={r["predicted"]: r["n"] for r in rows("SELECT predicted, COUNT(*) n FROM events GROUP BY predicted")},
        by_source={r["source"]: r["n"] for r in rows("SELECT source, COUNT(*) n FROM events GROUP BY source")})

@app.get("/api/events")
def events():
    w, a = [], []
    for k in ("severity", "status", "source", "predicted"):
        if request.args.get(k): w.append(f"{k}=?"); a.append(request.args[k])
    if request.args.get("q"): w.append("(src_ip LIKE ? OR dst_ip LIKE ?)"); a += [f"%{request.args['q']}%"] * 2
    lim = min(int(request.args.get("limit", 100)), 500)
    return jsonify(rows(f"SELECT * FROM events {'WHERE '+' AND '.join(w) if w else ''} ORDER BY seq DESC LIMIT ?", a + [lim]))

@app.get("/api/events/<eid>")
def event(eid):
    r = rows("SELECT * FROM events WHERE id=?", (eid,))
    return (jsonify(r[0]) if r else (jsonify(error="not found"), 404))

@app.patch("/api/events/<eid>")
def set_status(eid):
    s = (request.get_json(silent=True) or {}).get("status")
    if s not in core.STATUSES: return jsonify(error=f"status must be one of {core.STATUSES}"), 400
    c = core.conn(); cur = c.execute("UPDATE events SET status=? WHERE id=?", (s, eid)); c.commit(); c.close()
    return (jsonify(ok=True) if cur.rowcount else (jsonify(error="not found"), 404))

@app.post("/api/simulate")
def simulate():
    try: return jsonify(core.simulate((request.get_json(silent=True) or {}).get("kind", "")))
    except ValueError as e: return jsonify(error=str(e)), 400

@app.post("/api/ingest")
def ingest():
    try: return jsonify(core.ingest(request.get_json(force=True), "dataset"))
    except (ValueError, KeyError, TypeError) as e: return jsonify(error=str(e)), 400

@app.get("/api/verify")
def verify():
    c = core.conn(); r = core.verify(c); c.close(); return jsonify(r)

@app.get("/api/tamper-demo")
def tamper(): return jsonify(core.tamper_demo())

@app.get("/api/metrics")
def metrics():
    core.model()
    return jsonify(json.load(open(core.METRICS)))

@app.post("/api/import/csv")
def import_csv():
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".csv"): return jsonify(error="upload a .csv file"), 400
    if request.content_length and request.content_length > 5_000_000: return jsonify(error="max 5 MB"), 413
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "u.csv"); f.save(p)
        try: return jsonify(core.import_csv(p, json.loads(request.form.get("mapping", "{}"))))
        except Exception as e: return jsonify(error=str(e)), 400

def _upload(exts, max_mb):
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(exts): return None, (jsonify(error=f"upload a {'/'.join(exts)} file"), 400)
    if request.content_length and request.content_length > max_mb * 1e6: return None, (jsonify(error=f"max {max_mb} MB"), 413)
    return f, None

@app.post("/api/import/pcap")
def import_pcap():
    f, err = _upload((".pcap", ".pcapng"), 50)
    if err: return err
    import live
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "u.pcap" if f.filename.lower().endswith(".pcap") else "u.pcapng"); f.save(p)
        try: al = live.import_pcap(p); return jsonify(alerts=len(al), predicted=[x["predicted"] for x in al])
        except Exception as e: return jsonify(error=str(e)), 400

@app.post("/api/train")
def train_route():
    try:
        if request.files.get("file"):
            f, err = _upload((".csv",), 50)
            if err: return err
            with tempfile.TemporaryDirectory() as d:
                p = os.path.join(d, "t.csv"); f.save(p)
                m = core.train_csv(p, request.form["label_col"], json.loads(request.form.get("mapping") or "{}"), json.loads(request.form.get("label_map") or "{}") or None)
        else:
            core._model = core._iso = None; m = core.train()
        return jsonify(data=m["data"], accuracy=m["accuracy"], test_rows=m["test_rows"])
    except Exception as e: return jsonify(error=f"{type(e).__name__}: {e}"), 400

@app.post("/api/live/<act>")
def live_ctl(act):
    try:
        if LIVE is None: raise RuntimeError("live module unavailable")
        LIVE.start() if act == "start" else LIVE.stop(); return jsonify(LIVE.status())
    except RuntimeError as e: return jsonify(error=str(e)), 503

@app.get("/api/integrations")
def integ():
    return jsonify(elk=elk.health(), email={"enabled": notify.enabled()}, sms={"enabled": False, "note": "not implemented"},
                   live=LIVE.status() if LIVE else {"running": False, "error": "scapy/live module unavailable"})

@app.get("/")
def index(): return INDEX

INDEX = """<!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>AI Cyber Threat Logger</title><style>
:root{--bg:#0b1220;--card:#131c2e;--b:#22304a;--t:#e2e8f0;--m:#8a9bb8;--ac:#38bdf8}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--t);font:14px system-ui,sans-serif;display:flex;min-height:100vh}
nav{width:200px;background:#0a0f1b;border-right:1px solid var(--b);padding:16px;flex:none}nav h1{font-size:15px;color:var(--ac)}nav a{display:block;padding:8px;color:var(--m);cursor:pointer;border-radius:6px}nav a.on,nav a:hover{background:var(--card);color:var(--t)}
main{flex:1;padding:20px;overflow:auto;min-width:0}.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px}.c{background:var(--card);border:1px solid var(--b);border-radius:10px;padding:14px;margin-bottom:16px}.k{font-size:26px;font-weight:700}.m{color:var(--m);font-size:12px}
table{width:100%;border-collapse:collapse}td,th{padding:7px;border-bottom:1px solid var(--b);text-align:left;font-size:13px}tr.r:hover{background:#1a2740;cursor:pointer}.w{overflow-x:auto}
button,select,input{background:var(--bg);color:var(--t);border:1px solid var(--b);border-radius:6px;padding:6px 10px;margin:2px}button{cursor:pointer}button:hover{border-color:var(--ac)}
.s{padding:2px 8px;border-radius:9px;font-size:11px;font-weight:600}.Critical{background:#7f1d1d}.High{background:#9a3412}.Medium{background:#854d0e}.Low{background:#1e40af}.None{background:#14532d}
.bar{height:10px;background:var(--ac);border-radius:4px}.ok{color:#4ade80}.bad{color:#f87171}section{display:none}section.on{display:block}@media(max-width:700px){body{flex-direction:column}nav{width:auto}}</style></head><body>
<nav><h1>&#128737; Threat Logger</h1><a data-p=ov class=on>Overview</a><a data-p=ev>Events</a><a data-p=ml>Model</a><a data-p=ld>Ledger integrity</a><a data-p=dt>Data &amp; Live</a>
<p class=m>Data origin is shown per event: dataset / simulated / live.</p></nav><main>
<section id=ov class=on><div class=g id=cards></div><div class=c><b>Simulate test traffic</b> <span class=m>(labelled "simulated"; a model prediction is an alert, not a confirmed attack)</span><br>
<button data-k=benign>benign</button><button data-k=ddos>ddos</button><button data-k=bruteforce>bruteforce</button><button data-k=sqli>sqli</button><button data-k=portscan>portscan</button> <span id=simmsg class=m></span></div>
<div class=g><div class=c><b>By severity</b><div id=sev></div></div><div class=c><b>By predicted class</b><div id=cls></div></div></div></section>
<section id=ev><div class=c><input id=q placeholder="IP search"><select id=fs><option value="">severity</option><option>Critical<option>High<option>Medium<option>Low<option>None</select>
<select id=ft><option value="">status</option><option>new<option>investigating<option>confirmed<option>false_positive<option>closed</select><select id=fo><option value="">source</option><option>dataset<option>simulated<option>live</select><button id=go>Filter</button>
<div class=w><table><thead><tr><th>Time (UTC)<th>Src<th>Dst:port<th>Predicted<th>Conf<th>Severity<th>Source<th>Status</tr></thead><tbody id=tb></tbody></table></div><div id=empty class=m></div></div><div class=c id=det style=display:none></div></section>
<section id=ml><div class=c id=met>Loading...</div></section>
<section id=ld><div class=c><button id=vb>Verify live ledger</button><button id=tb2>Run tamper demo (safe temp copy)</button><pre id=vr class=m>Not run yet.</pre></div></section><section id=dt><div class=c><b>Import CSV</b> <span class=m>columns = the 6 model features (src_ip/dst_ip optional), or give a mapping</span><br><input type=file id=cf accept=.csv><input id=cm size=28 placeholder='mapping JSON (optional)'><button id=ci>Import</button></div>
<div class=c><b>Import PCAP</b> <span class=m>.pcap (pcapng needs scapy); authorised captures only</span><br><input type=file id=pf accept=.pcap,.pcapng><button id=pi>Import</button></div>
<div class=c><b>Train model</b> <span class=m>(replaces saved model; metrics on Model tab)</span><br><button id=ts>Retrain on SYNTHETIC data</button><br><input type=file id=tf accept=.csv><input id=tl placeholder="label column" size=12><input id=tm size=22 placeholder='feature mapping JSON'><input id=tlm size=28 placeholder='label map JSON'><button id=tc>Train on CSV</button></div>
<div class=c><b>Live capture</b> <span class=m>needs scapy + Npcap + Administrator</span><br><button id=ls>Start</button><button id=lx>Stop</button><button id=lr>Refresh</button><pre id=lst class=m></pre><div id=integ class=m></div></div><pre id=dtm class=m></pre></section></main><script>
const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const J=async(u,o)=>{const r=await fetch(u,o);const d=await r.json();if(!r.ok)throw new Error(d.error||r.status);return d};
document.querySelectorAll('nav a').forEach(a=>a.onclick=()=>{document.querySelectorAll('nav a,section').forEach(e=>e.classList.remove('on'));a.classList.add('on');$('#'+a.dataset.p).classList.add('on');load()});
const bars=o=>{const m=Math.max(1,...Object.values(o));return Object.entries(o).map(([k,v])=>`<div class=m>${esc(k)} (${v})</div><div class=bar style="width:${v/m*100}%"></div>`).join('')||'<span class=m>No data yet - click a simulate button.</span>'};
async function ov(){try{const s=await J('/api/summary');$('#cards').innerHTML=[['Total events',s.total],['Suspicious (alerts)',s.suspicious],['Critical',s.by_severity.Critical||0],['High',s.by_severity.High||0]].map(([a,b])=>`<div class=c><div class=k>${b}</div><div class=m>${a}</div></div>`).join('');$('#sev').innerHTML=bars(s.by_severity);$('#cls').innerHTML=bars(s.by_class)}catch(e){$('#cards').textContent='Error: '+e.message}}
async function ev(){try{const p=new URLSearchParams();[['q','#q'],['severity','#fs'],['status','#ft'],['source','#fo']].forEach(([k,i])=>$(i).value&&p.set(k,$(i).value));const d=await J('/api/events?'+p);$('#empty').textContent=d.length?'':'No events match.';
$('#tb').innerHTML=d.map(e=>`<tr class=r data-id=${e.id}><td>${esc(e.ts.slice(0,19))}<td>${esc(e.src_ip)}<td>${esc(e.dst_ip)}:${e.dport}<td>${esc(e.predicted)}<td>${e.confidence}<td><span class="s ${e.severity}">${e.severity}</span><td>${e.source}<td>${e.status}</tr>`).join('');
document.querySelectorAll('tr.r').forEach(r=>r.onclick=()=>det(r.dataset.id))}catch(e){$('#empty').textContent='Error: '+e.message}}
async function det(id){const e=await J('/api/events/'+id);const d=$('#det');d.style.display='block';d.innerHTML=`<b>Event ${esc(e.id)}</b><p class=m>Prediction by ${esc(e.rule)} - needs investigation, not proof of attack.</p><pre class=m>${esc(JSON.stringify(JSON.parse(e.features),null,1))}\\nanomaly: score ${e.anomaly_score} (${e.is_anomaly?'unusual vs benign baseline':'normal range'}) | detected by: ${esc(e.rule)}\\nMITRE candidate: ${esc(e.mitre||'none')}\\nnotes: ${esc(e.integration_note||'-')}\\nhash: ${e.hash}\\nprev: ${e.prev_hash}</pre>Status: <select id=st>${['new','investigating','confirmed','false_positive','closed'].map(s=>`<option ${s==e.status?'selected':''}>${s}`).join('')}</select><button id=sv>Save</button>`;
$('#sv').onclick=async()=>{await J('/api/events/'+id,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:$('#st').value})});ev()}}
async function ml(){try{const m=await J('/api/metrics');$('#met').innerHTML=`<b>Accuracy ${(m.accuracy*100).toFixed(1)}%</b> <span class=bad>${esc(m.data)}</span><p class=m>Train ${m.train_rows} / held-out test ${m.test_rows}. Metrics on synthetic data are optimistic.</p><table><tr><th>Class<th>Precision<th>Recall<th>F1</tr>${m.classes.map(c=>`<tr><td>${c}<td>${m.per_class[c].precision.toFixed(3)}<td>${m.per_class[c].recall.toFixed(3)}<td>${m.per_class[c]['f1-score'].toFixed(3)}`).join('')}</table><p><b>Confusion matrix</b> (rows=true, cols=predicted)</p><table><tr><th><th>${m.classes.join('<th>')}</tr>${m.confusion_matrix.map((r,i)=>`<tr><th>${m.classes[i]}<td>${r.join('<td>')}`).join('')}</table>`}catch(e){$('#met').textContent='Error: '+e.message}}
async function dt(){try{const i=await J('/api/integrations');$('#lst').textContent=JSON.stringify(i.live,null,1);$('#integ').textContent='ELK: '+JSON.stringify(i.elk)+' | email: '+(i.email.enabled?'on':'off')+' | SMS: not implemented'}catch(e){$('#lst').textContent=e.message}}
const post=async(u,fd)=>{try{const r=await J(u,{method:'POST',body:fd});$('#dtm').textContent=JSON.stringify(r,null,1);load()}catch(e){$('#dtm').textContent='Error: '+e.message}};
const fdo=(id,x)=>{const f=$(id).files[0];if(!f){$('#dtm').textContent='Choose a file first';return null}const d=new FormData();d.append('file',f);Object.entries(x||{}).forEach(([k,v])=>d.append(k,v));return d};
$('#ci').onclick=()=>{const d=fdo('#cf',{mapping:$('#cm').value});d&&post('/api/import/csv',d)};$('#pi').onclick=()=>{const d=fdo('#pf');d&&post('/api/import/pcap',d)};
$('#ts').onclick=()=>post('/api/train',new FormData());$('#tc').onclick=()=>{const d=fdo('#tf',{label_col:$('#tl').value,mapping:$('#tm').value,label_map:$('#tlm').value});d&&post('/api/train',d)};
const lv=a=>async()=>{try{await J('/api/live/'+a,{method:'POST'})}catch(e){$('#dtm').textContent='Live: '+e.message}dt()};$('#ls').onclick=lv('start');$('#lx').onclick=lv('stop');$('#lr').onclick=dt;
const load=()=>{ov();ev();ml();dt()};
document.querySelectorAll('[data-k]').forEach(b=>b.onclick=async()=>{try{const e=await J('/api/simulate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:b.dataset.k})});$('#simmsg').textContent=`-> predicted ${e.predicted} (${e.confidence}), severity ${e.severity}`;ov();ev()}catch(x){$('#simmsg').textContent=x.message}});
$('#go').onclick=ev;$('#vb').onclick=async()=>{const r=await J('/api/verify');$('#vr').innerHTML=`<span class="${r.ok?'ok':'bad'}">${r.ok?'PASS':'FAIL'}</span> - ${r.checked} records checked\\n`+esc(JSON.stringify(r.errors,null,1))};
$('#tb2').onclick=async()=>{const r=await J('/api/tamper-demo');$('#vr').textContent=`Before edit: ${r.before_tamper.ok?'PASS':'FAIL'}\\nAfter editing one record: ${r.after_tamper.ok?'PASS':'FAIL (tamper detected)'}\\n`+JSON.stringify(r.after_tamper.errors,null,1)};load();setInterval(ov,10000)</script></body></html>"""

if __name__ == "__main__":
    core.model()
    app.run(host="127.0.0.1", port=5000, debug=False)
