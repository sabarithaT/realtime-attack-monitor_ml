"""Optional Elasticsearch forwarding (direct HTTP, no Logstash). Env: ELK_URL (e.g. http://localhost:9200), ELK_INDEX(threat-events), ELK_API_KEY."""
import json, os, urllib.request
def health():
    u = os.environ.get("ELK_URL")
    if not u: return {"configured": False}
    try:
        with urllib.request.urlopen(u, timeout=3) as r: return {"configured": True, "reachable": r.status == 200}
    except Exception as e: return {"configured": True, "reachable": False, "error": type(e).__name__}
def forward(e):
    u = os.environ.get("ELK_URL")
    if not u: return None
    try:
        h = {"Content-Type": "application/json"}
        if os.environ.get("ELK_API_KEY"): h["Authorization"] = "ApiKey " + os.environ["ELK_API_KEY"]
        doc = {k: v for k, v in e.items()} | {"@timestamp": e["ts"], "features": json.loads(e["features"]), "mitre": json.loads(e["mitre"])}
        req = urllib.request.Request(f"{u}/{os.environ.get('ELK_INDEX','threat-events')}/_doc/{e['id']}", json.dumps(doc).encode(), h, method="PUT")
        urllib.request.urlopen(req, timeout=3).read(); return None
    except Exception as ex: return f"elk failed: {type(ex).__name__}"
