# AI-Driven Cyber Threat Logger
Python + Flask + SQLite + scikit-learn. Rule detectors + Random Forest + Isolation Forest + MITRE ATT&CK candidates + SHA-256 hash-chain ledger.

## Windows setup
    cd cyber-threat-logger
    python -m venv .venv
    .venv\Scripts\activate
    pip install -r requirements.txt
    python app.py          # http://127.0.0.1:5000 (trains a SYNTHETIC-data model on first start)
    python -m unittest discover -s tests -v

## Real dataset
Put a labelled CSV in `datasets/`, inspect its columns, map them to the 6 model features (`core.FEATURES`) and labels to `core.CLASSES`:
    python -c "import core; print(core.train_csv('datasets/x.csv','Label',mapping={'pkts_per_min':'<col>'},label_map={'BENIGN':'benign','DDoS':'ddos'}))"
UNSW-NB15 / CICIDS2017 are NOT bundled and were never run; their columns differ from the 6 features, so a mapping is required.
Import already-mapped rows: POST a .csv (max 5 MB) to `/api/import/csv`.

## Dashboard 'Data & Live' tab
Upload CSV / PCAP, retrain (synthetic or your CSV with label column + mapping JSON + label-map JSON), start/stop live capture, see ELK/email status.

## PCAP + live capture
Classic `.pcap` import works with no extra install (built-in reader, Ethernet/IPv4 TCP/UDP; tested with generated captures). `.pcapng` and live capture need `pip install scapy`.
Live capture (untested): 
Install Npcap (npcap.com, WinPcap-compatible mode), run the terminal as Administrator, authorised networks only.
`POST /api/live/start|stop`. PCAP: `python -c "import live; print(len(live.import_pcap('x.pcap')))"`.

## Optional integrations (set environment variables, see .env.example)
Email via SMTP (severity threshold, de-duplicated). Elasticsearch forwarding via ELK_URL (no Logstash config). SMS: not implemented.

## Limits
Hash chain is tamper-evident, not immutable. MITRE mapping, anomaly fields and notification flags are not part of the hash.
