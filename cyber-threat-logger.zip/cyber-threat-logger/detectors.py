"""Sliding-window rule detectors ported from the report's realtime_attack_monitor.py (DDoS / brute-force / SQLi)
plus port-scan. Pure Python (no scapy) so it is testable. Improvement: one alert per (src, rule) per cooldown,
instead of one log row per packet over threshold. Payloads are inspected, never stored."""
from collections import defaultdict, deque
import core

DDOS, BRUTE, SCAN, WINDOW, COOLDOWN = 50, 5, 15, 60, 60   # pkts/min, failed logins/min, distinct ports/min, seconds

class RuleEngine:
    def __init__(self): self.w = defaultdict(deque); self.last = {}
    def observe(self, p):
        """p: dict(ts, src_ip, dst_ip, dport, length, payload(str|None)). Returns list of (rec, rule_label)."""
        q = self.w[p["src_ip"]]; pay = (p.get("payload") or "")
        q.append((p["ts"], p["dport"], p["length"], core.count_sql(pay), int("failed login" in pay.lower())))
        while q and p["ts"] - q[0][0] > WINDOW: q.popleft()
        n, ports = len(q), {x[1] for x in q}
        sql, fails = sum(x[3] for x in q), sum(x[4] for x in q)
        hits = [l for l, ok in (("ddos", n > DDOS), ("bruteforce", fails > BRUTE), ("sqli", sql > 0), ("portscan", len(ports) > SCAN)) if ok]
        out = []
        for l in hits:
            if p["ts"] - self.last.get((p["src_ip"], l), -1e18) < COOLDOWN: continue
            self.last[(p["src_ip"], l)] = p["ts"]
            f = {"pkts_per_min": float(n), "avg_pkt_bytes": sum(x[2] for x in q) / n, "dport": float(p["dport"]),
                 "failed_logins": float(fails), "sql_hits": float(sql), "distinct_ports": float(len(ports))}
            out.append(({"src_ip": p["src_ip"], "dst_ip": p["dst_ip"], "proto": "TCP", "features": f}, l))
        return out

def process(packets, source="live", c=None, engine=None):
    eng, alerts = engine or RuleEngine(), []
    for p in packets:
        for rec, label in eng.observe(p): alerts.append(core.ingest(rec, source, c, rule_label=label))
    return alerts
