"""Optional SMTP alerts. Env: NOTIFY_SMTP_HOST, NOTIFY_SMTP_PORT(587), NOTIFY_USER, NOTIFY_PASSWORD, NOTIFY_FROM, NOTIFY_TO, NOTIFY_MIN_SEVERITY(High).
SMS is NOT implemented (needs a paid provider account, e.g. Twilio)."""
import os, smtplib
from email.message import EmailMessage
RANK = {"None": 0, "Low": 1, "Medium": 2, "High": 3, "Critical": 4}
def enabled(): return bool(os.environ.get("NOTIFY_SMTP_HOST") and os.environ.get("NOTIFY_TO"))
def send_if_needed(e, c):
    if not enabled() or RANK.get(e["severity"], 0) < RANK.get(os.environ.get("NOTIFY_MIN_SEVERITY", "High"), 3): return None
    if c.execute("SELECT notified FROM events WHERE id=?", (e["id"],)).fetchone()["notified"]: return None   # dedupe
    try:
        m = EmailMessage(); m["Subject"] = f"[{e['severity']}] {e['predicted']} alert from {e['src_ip']}"
        m["From"] = os.environ.get("NOTIFY_FROM", os.environ.get("NOTIFY_USER", "logger@localhost")); m["To"] = os.environ["NOTIFY_TO"]
        m.set_content(f"Model/rule prediction (needs investigation, not confirmed): {e['predicted']}\nSeverity: {e['severity']}\nSource: {e['source']}\nEvent: {e['id']}\nTime: {e['ts']}")
        with smtplib.SMTP(os.environ["NOTIFY_SMTP_HOST"], int(os.environ.get("NOTIFY_SMTP_PORT", 587)), timeout=10) as s:
            s.starttls()
            if os.environ.get("NOTIFY_USER"): s.login(os.environ["NOTIFY_USER"], os.environ.get("NOTIFY_PASSWORD", ""))
            s.send_message(m)
        c.execute("UPDATE events SET notified=1 WHERE id=?", (e["id"],)); c.commit(); return None
    except Exception as ex: return f"email failed: {type(ex).__name__}"
