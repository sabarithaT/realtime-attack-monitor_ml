"""Scapy adapter: live capture + PCAP import. UNTESTED here (scapy not installable in the build sandbox).
Windows: install Npcap (https://npcap.com, tick 'WinPcap API-compatible mode'), run the terminal as Administrator for live capture.
Only capture networks you are authorised to monitor."""
import os, threading, time
import detectors

def _scapy():
    try:
        import scapy.all as s; return s
    except Exception as e: raise RuntimeError(f"scapy unavailable ({e}); pip install scapy and install Npcap") from e

def to_dict(pkt, s):
    ip = pkt.getlayer(s.IP) or pkt.getlayer(s.IPv6)
    if ip is None: return None
    l4 = pkt.getlayer(s.TCP) or pkt.getlayer(s.UDP)
    raw = bytes(pkt[s.Raw].load[:512]) if pkt.haslayer(s.Raw) else b""   # truncated, inspected for patterns only, never stored
    return {"ts": float(pkt.time), "src_ip": ip.src, "dst_ip": ip.dst, "dport": int(l4.dport) if l4 else 0, "length": len(pkt), "payload": raw.decode(errors="ignore")}

import struct

def read_pcap_pure(path, max_packets=200000):
    """Minimal classic-pcap reader (Ethernet/raw IPv4, TCP/UDP). No scapy needed. pcapng is not supported here."""
    with open(path, "rb") as f:
        h = f.read(24)
        if len(h) < 24: raise ValueError("file too short to be a pcap")
        end = {b"\xd4\xc3\xb2\xa1": "<", b"\xa1\xb2\xc3\xd4": ">"}.get(h[:4])
        if not end: raise ValueError("not a classic .pcap file (pcapng needs scapy)")
        link = struct.unpack(end + "I", h[20:24])[0]
        if link not in (1, 101): raise ValueError(f"unsupported link type {link}")
        n = 0
        while n < max_packets:
            ph = f.read(16)
            if len(ph) < 16: break
            sec, usec, incl, orig = struct.unpack(end + "IIII", ph); data = f.read(incl); n += 1
            if link == 1:
                if len(data) < 14 or data[12:14] != b"\x08\x00": continue
                data = data[14:]
            if len(data) < 20 or data[0] >> 4 != 4: continue
            ihl, proto = (data[0] & 15) * 4, data[9]; l4 = data[ihl:]
            if proto == 6 and len(l4) >= 20: dport, pay = struct.unpack(">H", l4[2:4])[0], l4[(l4[12] >> 4) * 4:]
            elif proto == 17 and len(l4) >= 8: dport, pay = struct.unpack(">H", l4[2:4])[0], l4[8:]
            else: dport, pay = 0, b""
            yield {"ts": sec + usec / 1e6, "src_ip": ".".join(map(str, data[12:16])), "dst_ip": ".".join(map(str, data[16:20])),
                   "dport": dport, "length": orig, "payload": pay[:512].decode(errors="ignore")}   # truncated, never stored

def import_pcap(path, c=None, max_mb=50):
    if not path.lower().endswith((".pcap", ".pcapng")) or not os.path.isfile(path): raise ValueError("need an existing .pcap/.pcapng file")
    if os.path.getsize(path) > max_mb * 1e6: raise ValueError(f"file larger than {max_mb} MB")
    try: s = _scapy()
    except RuntimeError: s = None
    if s is None:
        if path.lower().endswith(".pcapng"): raise ValueError("pcapng requires scapy; install scapy or convert to .pcap")
        return detectors.process(read_pcap_pure(path), "dataset", c)
    return detectors.process((x for x in (to_dict(p, s) for p in s.rdpcap(path)) if x), "dataset", c)

class Live:
    def __init__(self): self.t = None; self.stop_ev = threading.Event(); self.error = None; self.count = 0; self.alerts = 0
    def start(self, iface=None):
        if self.running(): return
        s = _scapy(); eng = detectors.RuleEngine(); self.stop_ev.clear(); self.error = None
        def cb(p):
            d = to_dict(p, s); self.count += 1
            if d: self.alerts += len(detectors.process([d], "live", None, eng))
        def run():
            try: s.sniff(iface=iface, prn=cb, store=False, stop_filter=lambda _: self.stop_ev.is_set())
            except Exception as e: self.error = f"{type(e).__name__}: {e} (need Npcap + Administrator?)"
        self.t = threading.Thread(target=run, daemon=True); self.t.start()
    def stop(self): self.stop_ev.set()
    def running(self): return bool(self.t and self.t.is_alive())
    def status(self): return {"running": self.running(), "packets_seen": self.count, "alerts": self.alerts, "error": self.error}
