"""Detection category -> MITRE ATT&CK technique (Enterprise). A category is an alert label; the technique is
a *candidate* mapping for analysts, not proof the technique was used. Source: https://attack.mitre.org"""
MAP = {
 "ddos": {"id": "T1498", "name": "Network Denial of Service", "tactic": "Impact"},
 "bruteforce": {"id": "T1110", "name": "Brute Force", "tactic": "Credential Access"},
 "sqli": {"id": "T1190", "name": "Exploit Public-Facing Application", "tactic": "Initial Access"},
 "portscan": {"id": "T1046", "name": "Network Service Discovery", "tactic": "Discovery"},
}
def lookup(label):
    t = MAP.get(label)   # benign / unknown -> no mapping (insufficient evidence)
    return dict(t, url=f"https://attack.mitre.org/techniques/{t['id']}/") if t else None
